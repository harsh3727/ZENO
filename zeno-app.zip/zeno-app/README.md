# ZENO — Deploy to Vercel (5 minutes)

Zero-waste Expense & Net-growth Optimizer  
White + Royal Green · Live AI Financial Agent

---

## Folder Structure

```
zeno-app/
├── api/
│   └── chat.js          ← Secure AI backend (your API key lives here)
├── public/
│   └── index.html       ← Full frontend
├── vercel.json          ← Routing config
├── package.json
└── README.md
```

---

## Step 1 — Install Vercel CLI

```bash
npm install -g vercel
```

---

## Step 2 — Deploy

From inside the `zeno-app` folder:

```bash
cd zeno-app
vercel
```

Follow the prompts:
- Set up and deploy? **Y**
- Which scope? Select your account
- Link to existing project? **N**
- Project name: `zeno-app` (or anything)
- Directory: `./` (current)

---

## Step 3 — Set your API Key (critical)

After first deploy, go to:

**Vercel Dashboard → Your Project → Settings → Environment Variables**

Add:
| Name | Value |
|------|-------|
| `ANTHROPIC_API_KEY` | `sk-ant-...your key here...` |

Then redeploy:
```bash
vercel --prod
```

---

## Step 4 — Open your live URL

Vercel gives you a URL like:
`https://zeno-app-xyz.vercel.app`

The AI Agent page now calls `/api/chat` securely on the server.  
Your API key is **never exposed** in the browser.

---

## How the AI works

1. User types a question in the AI Financial Agent page
2. Browser sends POST to `/api/chat` (your own server)
3. Server reads `ANTHROPIC_API_KEY` from environment
4. Server calls the AI API securely
5. Response returns to browser

The frontend has **zero** knowledge of your API key.

---

## Local Development

```bash
vercel dev
```

This runs both the frontend and the `/api/chat` backend locally at `http://localhost:3000`.

For local dev, create a `.env` file:
```
ANTHROPIC_API_KEY=sk-ant-...
```

---

## Features

| Feature | Works |
|---------|-------|
| Dashboard with Empowerment Score | ✅ |
| Unified Eco-Wallet (same parent brand) | ✅ |
| Locked Voucher Smart Advisor | ✅ |
| Expense Builder (editable) | ✅ |
| Age-based Goal Engine | ✅ |
| ₹1,000 Auto-Invest Trigger | ✅ |
| Growth List / Investment Sweep | ✅ |
| Transaction Ledger | ✅ |
| Live AI Financial Agent | ✅ (needs API key) |
| Cashback-to-investment calculator | ✅ |
